add performance test here
